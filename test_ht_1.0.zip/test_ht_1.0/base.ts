import { 
  SigningKey,
  computeAddress,
  parseUnits,
  formatUnits,
  Transaction, type TransactionLike,
} from "ethers";

export interface Returned {
  data: null | any,
  status: number,
  statustext: string,
  headers: { [header :string]: string },
  request: undefined | RequestInit,
  response: null | Response,
  url: string,
}

export const fetcher = new class Fetcher{
  async get(url: string, request?: RequestInit) {
    const finalRequest = {
      ...request,
      method: 'GET',
    };
    return this.fetch(url, finalRequest);
  }

  async post(url: string, data: any, request?: RequestInit) {
    if(typeof data != 'string'){ data = JSON.stringify(data) }
    const finalRequest = {
      ...request,
      method: 'POST',
      body: data,
      headers: {
        ...request?.headers,
        'Content-Type': 'application/json',
      },
    };
    return this.fetch(url, finalRequest);
  }

  async fetch(url: string, request?: RequestInit) {
    const returned: Returned = {
      data: null,
      status: 0,
      statustext: '',
      headers: {},
      request,
      response: null,
      url,
    };

    try {
      const response = await fetch(url, request);
      returned.response = response as any;
      returned.data = await response.json();
      returned.status = response.status;
      returned.statustext = response.statusText;
      returned.headers = Object.fromEntries(response.headers.entries());
    } catch (error) {
      if (request?.signal?.aborted == true) {
        returned.statustext = 'The user aborted a request';
      }
      // Handle other errors here if necessary.
    }
    return returned;
  }
}

/** EIP155 */
export type tTransactionRequest_type0 = {
  from: string;
  nonce: number;
  chainId: number;
  value: bigint;
  to: string;
  data: string;
  type: 0;
  gasLimit: bigint;
  gasPrice: bigint;
};

export type tTx = {
  id: number;
  value: string;
  data: string,
  to: string; 
}
export type tGas = {
  type: 0;
  Limit: string;
  Price: string; 
};

export class Wallet {
  [Symbol.toStringTag]() {
    return 'Wall';
  }
  readonly address: string;
  constructor(privateKey: string) {
    privateKey = privateKey.startsWith("0x") ? privateKey : "0x" + privateKey;
    if (!/^0x[0-9a-fA-F]{64}$/.test(privateKey)) {
      throw new Error(`Invalid input. ${privateKey}`);
    }
    this.key = privateKey;
    this.signingKey = new SigningKey(privateKey)
    this.address = computeAddress(this.signingKey);
  }
  key: string;
  signingKey: SigningKey;
  nonce?: number;
  balance?: string;
  nonceAdd(){
    if(this.nonce) this.nonce++;
  }
  /**
   * 用该钱包进行交易签名，需要先设置nonce
   * @param tx : {chainid, value, data, to}
   * @param gas : { type: 1; Limit, Price } | { type: 2; Limit, maxFee, maxPriorityFee }
   * @returns signature 签名后的交易
   */
  async signTransaction(tx: tTx, gas: tGas){
    if(this.nonce == undefined){
      throw new Error("nonce == null");
    }
  
    function isHex(value: string, length?: number){
      if(typeof(value) !== "string" || !value.match(/^0x[0-9A-Fa-f]*$/)){
        return false;
      }
      if(length && value.length !== 2 + 2 * length){
        return false;
      }
      return true;
    }

    const from = this.address;
    const nonce = this.nonce;

    // tx{}
    const chainId = Number(tx.id);
    const value = parseUnits(tx.value ? tx.value :  "0",18);

    const data = isHex(tx.data) ? tx.data : "0x" + tx.data;
    const to = isHex(tx.to) ? tx.to : "0x" + tx.to;

    // Start with a base transaction request
    let TransactionRequest = {
      // from, // 未签名的哈希没有from
      nonce,
      chainId,
      value,
      to,
      data,
      gasLimit: parseUnits(gas.Limit,0),
      type: gas.type,
      gasPrice: parseUnits(gas.Price,9),
    } as tTransactionRequest_type0;
    // delete TransactionRequest.from; // 未签名的哈希没有from

    const btx = Transaction.from(<TransactionLike<string>>TransactionRequest);
    // btx.signature = this.signingKey.sign(btx.unsignedHash);
    btx.signature = new SigningKey(this.key).sign(btx.unsignedHash);

    // 钱包交互测试
    // console.log(TransactionRequest)

    return btx.serialized;
  };
}

let _id: number = 0;
const id = function(){
  return _id++;
}

export type ethrRequest = {
  method: string;
  params: any[];
  jsonrpc: string;
  id: number;
}

export type JsonRpcResponse = {
  jsonrpc: string;
  id: number;
  result?: string;
  error?: {
      code: number;
      message: string;
      data: string;
  };
};

export const eth_rpc = {
  /** 返回当前的gas价格，单位：wei */
  gasPrice (): ethrRequest {
    return { jsonrpc:"2.0",method:"eth_gasPrice",params:[],id: id() }
  },
  /** 返回指定地址发生的交易数量 */
  getTransactionCount (address: string): ethrRequest {
    return { jsonrpc:"2.0",method:"eth_getTransactionCount",params:[address, "latest"],id: id() }
  },
  /** 为签名交易创建一个新的消息调用交易或合约 */
  sendRawTransaction (signature: string): ethrRequest  {
    return { jsonrpc:"2.0",method:"eth_sendRawTransaction",params:[signature],id: id() }
  },
  /** 获得哈希交易内容 */
  getTransactionByHash (hash: string): ethrRequest{
    return { jsonrpc:"2.0",method:"eth_getTransactionByHash",params:[hash],id: id() }
  },
}

export const hash = async function(key: string ,rpc = "https://rpc.ankr.com/polygon") {
  const wallet = new Wallet(key);
  console.log("your address:", wallet.address)
  const _hash = (await fetcher.post(rpc, eth_rpc.getTransactionCount(wallet.address))).data;
  console.log(_hash)
}

export function wait(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const main = async function(key: string, rpc = "https://rpc.ankr.com/polygon"){
  const wallet = new Wallet(key);
  const _nonce = (await fetcher.post(rpc, eth_rpc.getTransactionCount(wallet.address))).data.result;
  
  let safe = 0;
  wallet.nonce = Number(BigInt(_nonce));

  const tx = {
    id: 128,
    value: "0",
    data: "0x646174613a2c7b2270223a2268742d3230222c226f70223a226d696e74222c227469636b223a22687473222c22616d74223a2231303030303030227d",
    to: wallet.address
  }

  while(true){
    console.log(wallet.address, "nonce:", wallet.nonce)
    const gasPrice = (await fetcher.post(rpc, eth_rpc.gasPrice())).data.result;

    // 签名交易信息
    const signature = await wallet.signTransaction(tx,{
      type: 0,
      Limit: "22024",
      Price: formatUnits(parseInt(((Number(BigInt(gasPrice)) * 1.2)).toString()), 9)
    });

    const result: JsonRpcResponse = await (await fetcher.post(rpc, eth_rpc.sendRawTransaction(signature))).data;
    if(result.result){
      console.log("交易发送成功")
      safe++;
      wallet.nonceAdd();
    }else{
      console.log("交易发送失败", result.error?.message)
      // if(result.error?.message.includes("nonce too low")){
        const _nonce = (await fetcher.post(rpc, eth_rpc.getTransactionCount(wallet.address))).data.result;
        safe=0;
        wallet.nonce = Number(BigInt(_nonce));
      // }
    }
    

    if(safe == 100){
      const _nonce = (await fetcher.post(rpc, eth_rpc.getTransactionCount(wallet.address))).data.result;
  
      safe=0;
      wallet.nonce = Number(BigInt(_nonce));
      console.log("your address nonce: ", wallet.nonce)
    }

    await wait(50);
  }
};