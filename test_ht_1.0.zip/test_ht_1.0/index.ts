import { main } from './base';
const key = "";
const rpc = "自己去ankr开";
main(key, rpc)